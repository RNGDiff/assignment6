# Makwans Dashboard

## Beskrivning

Detta är en enkel webbplats byggd med HTML, CSS och JavaScript.
Webbplatsen är en Dashboard, där man kan utnyttja snabblänkar, se väder, nyheter eller anteckna.

## Struktur

- `index.html`: Huvudsidan för webbplatsen
- `css/style.css`: Stilar för webbplatsen
- `js/script.js`: JavaScript för funktionalitet

## Användning

1. Ladda ner och extrahera zip-filen.
2. Öppna `index.html` i din webbläsare för att visa webbplatsen.
